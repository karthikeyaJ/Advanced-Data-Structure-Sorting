

#pragma once
#include "Interfaces03.h"
#include "vector.h"

class RadixSort : public IRadixSort
{
public:
	//RadixSort() {}
	RadixSort() :evecSize(0) {}
	~RadixSort() {}
	void sort(std::vector<std::string> & data);
private:
	vector<std::string> cvector;
	void sorted(vector<std::string> & data, int counting);
//	vector<std::string> cvector;

    vector<std::string> dvector;
	vector<std::string> evector[50000];
	//int evecSize = 0;
	int evecSize;
};