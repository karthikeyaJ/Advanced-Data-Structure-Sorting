#include "Interfaces03.h"

#include "RunningMedian.h"


std::vector<int> RunningMedian::compute(std::vector<int> vec, int window_size)
{
	std::vector<int> k;
	return k;

}